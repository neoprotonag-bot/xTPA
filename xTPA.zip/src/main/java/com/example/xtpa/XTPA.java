package com.example.xtpa;

import com.example.xtpa.managers.CooldownManager;
import com.example.xtpa.managers.RequestManager;
import com.example.xtpa.managers.WarmupManager;
import com.example.xtpa.models.UserSettings;
import org.bukkit.plugin.java.JavaPlugin;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class XTPA extends JavaPlugin {
    private static XTPA instance;
    private RequestManager requestManager;
    private WarmupManager warmupManager;
    private CooldownManager cooldownManager;
    private final Map<UUID, UserSettings> userSettings = new HashMap<>();

    @Override
    public void onEnable() {
        instance = this;
        saveDefaultConfig();

        this.requestManager = new RequestManager(this);
        this.warmupManager = new WarmupManager(this);
        this.cooldownManager = new CooldownManager(this);

        getCommand("tpa").setExecutor(new com.example.xtpa.commands.TPACommand(this));
        getCommand("tpaccept").setExecutor(new com.example.xtpa.commands.TPAcceptCommand(this));
        
        getLogger().info("xTPA has been enabled!");
    }

    @Override
    public void onDisable() {
        getLogger().info("xTPA has been disabled!");
    }

    public static XTPA getInstance() {
        return instance;
    }

    public RequestManager getRequestManager() {
        return requestManager;
    }

    public WarmupManager getWarmupManager() {
        return warmupManager;
    }

    public CooldownManager getCooldownManager() {
        return cooldownManager;
    }

    public UserSettings getUserSettings(UUID uuid) {
        return userSettings.computeIfAbsent(uuid, k -> new UserSettings());
    }
}
