package com.example.xtpa.models;

public class UserSettings {
    private boolean tpaEnabled = true;

    public boolean isTpaEnabled() {
        return tpaEnabled;
    }

    public void setTpaEnabled(boolean tpaEnabled) {
        this.tpaEnabled = tpaEnabled;
    }
}
