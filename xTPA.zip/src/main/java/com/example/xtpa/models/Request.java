package com.example.xtpa.models;

import java.time.Instant;
import java.util.UUID;

public class Request {
    public enum Type { TPA, TPAHERE }
    private final UUID id;
    private final UUID sender;
    private final UUID receiver;
    private final Type type;
    private final Instant timestamp;
    private final long expirationSeconds;

    public Request(UUID sender, UUID receiver, Type type, long expirationSeconds) {
        this.id = UUID.randomUUID();
        this.sender = sender;
        this.receiver = receiver;
        this.type = type;
        this.timestamp = Instant.now();
        this.expirationSeconds = expirationSeconds;
    }

    public boolean isExpired() {
        return Instant.now().isAfter(timestamp.plusSeconds(expirationSeconds));
    }

    public UUID getSender() { return sender; }
    public UUID getReceiver() { return receiver; }
    public Type getType() { return type; }
    public UUID getId() { return id; }
}
