package com.example.xtpa.commands;

import com.example.xtpa.XTPA;
import com.example.xtpa.models.Request;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;

public class TPACommand implements CommandExecutor {
    private final XTPA plugin;

    public TPACommand(XTPA plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command, @NotNull String label, @NotNull String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Only players can use this command.");
            return true;
        }

        if (args.length < 1) {
            player.sendMessage(MiniMessage.miniMessage().deserialize("<red>Usage: /tpa <player>"));
            return true;
        }

        Player target = Bukkit.getPlayer(args[0]);
        if (target == null) {
            player.sendMessage(MiniMessage.miniMessage().deserialize("<red>Player not found."));
            return true;
        }

        if (target.equals(player)) {
            player.sendMessage(MiniMessage.miniMessage().deserialize("<red>You cannot teleport to yourself."));
            return true;
        }

        plugin.getRequestManager().sendRequest(player, target, Request.Type.TPA);
        return true;
    }
}
