package com.example.xtpa.managers;

import com.example.xtpa.XTPA;
import com.example.xtpa.models.Request;
import com.example.xtpa.utils.SchedulerUtils;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Player;

public class WarmupManager {
    private final XTPA plugin;

    public WarmupManager(XTPA plugin) {
        this.plugin = plugin;
    }

    public void startWarmup(Request request) {
        Player sender = Bukkit.getPlayer(request.getSender());
        Player receiver = Bukkit.getPlayer(request.getReceiver());
        
        Player traveler = (request.getType() == Request.Type.TPA) ? sender : receiver;
        Player target = (request.getType() == Request.Type.TPA) ? receiver : sender;

        if (traveler == null || target == null) return;

        int seconds = plugin.getConfig().getInt("settings.warmup", 5);
        Location startLoc = traveler.getLocation();

        traveler.sendMessage(MiniMessage.miniMessage().deserialize("<yellow>Teleporting in " + seconds + " seconds. Don't move!"));

        SchedulerUtils.runTaskLater(plugin, traveler, () -> {
            if (!traveler.isOnline() || !target.isOnline()) return;

            if (traveler.getLocation().distance(startLoc) > 0.5) {
                traveler.sendMessage(MiniMessage.miniMessage().deserialize("<red>Teleport cancelled: You moved."));
                return;
            }

            SchedulerUtils.teleportAsync(traveler, target.getLocation());
            
            traveler.playSound(traveler.getLocation(), Sound.ENTITY_ENDERMAN_TELEPORT, 1f, 1f);
            traveler.getWorld().spawnParticle(Particle.PORTAL, traveler.getLocation(), 50);
        }, 20L * seconds);
    }
}
