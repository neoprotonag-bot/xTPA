package com.example.xtpa.managers;

import com.example.xtpa.XTPA;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class CooldownManager {
    private final XTPA plugin;
    private final Map<UUID, Long> cooldowns = new HashMap<>();

    public CooldownManager(XTPA plugin) {
        this.plugin = plugin;
    }

    public void setCooldown(UUID uuid, int seconds) {
        cooldowns.put(uuid, System.currentTimeMillis() + (seconds * 1000L));
    }

    public long getRemaining(UUID uuid) {
        Long end = cooldowns.get(uuid);
        if (end == null) return 0;
        long remaining = end - System.currentTimeMillis();
        return Math.max(0, remaining / 1000);
    }

    public boolean isOnCooldown(UUID uuid) {
        return getRemaining(uuid) > 0;
    }
}
