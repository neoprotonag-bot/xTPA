package com.example.xtpa.managers;

import com.example.xtpa.XTPA;
import com.example.xtpa.models.Request;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class RequestManager {
    private final XTPA plugin;
    private final Map<UUID, List<Request>> requests = new ConcurrentHashMap<>();

    public RequestManager(XTPA plugin) {
        this.plugin = plugin;
        Bukkit.getScheduler().runTaskTimerAsynchronously(plugin, this::cleanupExpired, 20L, 20L * 5);
    }

    public void sendRequest(Player sender, Player receiver, Request.Type type) {
        if (plugin.getCooldownManager().isOnCooldown(sender.getUniqueId())) {
            sender.sendMessage(MiniMessage.miniMessage().deserialize("<red>You are on cooldown for " + plugin.getCooldownManager().getRemaining(sender.getUniqueId()) + "s."));
            return;
        }

        if (!plugin.getUserSettings(receiver.getUniqueId()).isTpaEnabled()) {
            sender.sendMessage(MiniMessage.miniMessage().deserialize("<red>This player has TPA disabled."));
            return;
        }

        Request req = new Request(sender.getUniqueId(), receiver.getUniqueId(), type, plugin.getConfig().getLong("settings.timeout", 60));
        requests.computeIfAbsent(receiver.getUniqueId(), k -> new ArrayList<>()).add(req);

        var mm = MiniMessage.miniMessage();
        sender.sendMessage(mm.deserialize("<green>Request sent to <yellow>" + receiver.getName()));
        
        String actionCommand = "/tpaccept";
        receiver.sendMessage(mm.deserialize("<green>" + sender.getName() + " <gray>wants to teleport to you. <click:run_command:'" + actionCommand + "'><bold><green>[ACCEPT]</click>"));
    }

    public void acceptRequest(Player receiver) {
        List<Request> pending = requests.get(receiver.getUniqueId());
        if (pending == null || pending.isEmpty()) {
            receiver.sendMessage(MiniMessage.miniMessage().deserialize("<red>No pending requests."));
            return;
        }

        Request req = pending.get(pending.size() - 1);
        Player sender = Bukkit.getPlayer(req.getSender());
        if (sender == null) {
            receiver.sendMessage(MiniMessage.miniMessage().deserialize("<red>Player is offline."));
            pending.remove(req);
            return;
        }

        plugin.getWarmupManager().startWarmup(req);
        pending.remove(req);
        
        // Set cooldown after successful acceptance/start
        plugin.getCooldownManager().setCooldown(req.getSender(), plugin.getConfig().getInt("settings.cooldown", 120));
    }

    public List<Request> getPending(UUID uuid) {
        return requests.getOrDefault(uuid, new ArrayList<>());
    }

    private void cleanupExpired() {
        requests.values().forEach(list -> list.removeIf(Request::isExpired));
    }
}
